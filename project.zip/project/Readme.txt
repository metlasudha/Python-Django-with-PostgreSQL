Requirements to run 

Python 
pycharm community IDE
PostgreSQL
pgAdmin4
pip install django
pip install psycopg2

set the database connection

python manage.py runserver