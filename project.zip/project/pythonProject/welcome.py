print("Hello World")
print("Welcome to Django with PostgreSQL")