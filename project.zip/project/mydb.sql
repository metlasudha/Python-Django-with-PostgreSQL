--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

-- Started on 2023-04-18 10:08:53

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3467 (class 1262 OID 16398)
-- Name: mydb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mydb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE mydb OWNER TO postgres;

\connect mydb

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 3444 (class 0 OID 16422)
-- Dependencies: 221
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3446 (class 0 OID 16430)
-- Dependencies: 223
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3442 (class 0 OID 16416)
-- Dependencies: 219
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.auth_permission VALUES (1, 'Can add log entry', 1, 'add_logentry');
INSERT INTO public.auth_permission VALUES (2, 'Can change log entry', 1, 'change_logentry');
INSERT INTO public.auth_permission VALUES (3, 'Can delete log entry', 1, 'delete_logentry');
INSERT INTO public.auth_permission VALUES (4, 'Can view log entry', 1, 'view_logentry');
INSERT INTO public.auth_permission VALUES (5, 'Can add permission', 2, 'add_permission');
INSERT INTO public.auth_permission VALUES (6, 'Can change permission', 2, 'change_permission');
INSERT INTO public.auth_permission VALUES (7, 'Can delete permission', 2, 'delete_permission');
INSERT INTO public.auth_permission VALUES (8, 'Can view permission', 2, 'view_permission');
INSERT INTO public.auth_permission VALUES (9, 'Can add group', 3, 'add_group');
INSERT INTO public.auth_permission VALUES (10, 'Can change group', 3, 'change_group');
INSERT INTO public.auth_permission VALUES (11, 'Can delete group', 3, 'delete_group');
INSERT INTO public.auth_permission VALUES (12, 'Can view group', 3, 'view_group');
INSERT INTO public.auth_permission VALUES (13, 'Can add user', 4, 'add_user');
INSERT INTO public.auth_permission VALUES (14, 'Can change user', 4, 'change_user');
INSERT INTO public.auth_permission VALUES (15, 'Can delete user', 4, 'delete_user');
INSERT INTO public.auth_permission VALUES (16, 'Can view user', 4, 'view_user');
INSERT INTO public.auth_permission VALUES (17, 'Can add content type', 5, 'add_contenttype');
INSERT INTO public.auth_permission VALUES (18, 'Can change content type', 5, 'change_contenttype');
INSERT INTO public.auth_permission VALUES (19, 'Can delete content type', 5, 'delete_contenttype');
INSERT INTO public.auth_permission VALUES (20, 'Can view content type', 5, 'view_contenttype');
INSERT INTO public.auth_permission VALUES (21, 'Can add session', 6, 'add_session');
INSERT INTO public.auth_permission VALUES (22, 'Can change session', 6, 'change_session');
INSERT INTO public.auth_permission VALUES (23, 'Can delete session', 6, 'delete_session');
INSERT INTO public.auth_permission VALUES (24, 'Can view session', 6, 'view_session');
INSERT INTO public.auth_permission VALUES (25, 'Can add product', 7, 'add_product');
INSERT INTO public.auth_permission VALUES (26, 'Can change product', 7, 'change_product');
INSERT INTO public.auth_permission VALUES (27, 'Can delete product', 7, 'delete_product');
INSERT INTO public.auth_permission VALUES (28, 'Can view product', 7, 'view_product');
INSERT INTO public.auth_permission VALUES (29, 'Can add offers', 8, 'add_offers');
INSERT INTO public.auth_permission VALUES (30, 'Can change offers', 8, 'change_offers');
INSERT INTO public.auth_permission VALUES (31, 'Can delete offers', 8, 'delete_offers');
INSERT INTO public.auth_permission VALUES (32, 'Can view offers', 8, 'view_offers');
INSERT INTO public.auth_permission VALUES (33, 'Can add my model', 9, 'add_mymodel');
INSERT INTO public.auth_permission VALUES (34, 'Can change my model', 9, 'change_mymodel');
INSERT INTO public.auth_permission VALUES (35, 'Can delete my model', 9, 'delete_mymodel');
INSERT INTO public.auth_permission VALUES (36, 'Can view my model', 9, 'view_mymodel');


--
-- TOC entry 3448 (class 0 OID 16436)
-- Dependencies: 225
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.auth_user VALUES (1, 'pbkdf2_sha256$600000$USbDLXUZZWTVLxi0qm5d3o$fgNCPeSejZV6MRiVFruW9v2m5+37YL5N42/YO+Xb0wY=', '2023-04-17 20:26:39.982031+05:30', true, 'admin', '', '', 'admin@gamil.com', true, true, '2023-04-17 20:25:55.797442+05:30');
INSERT INTO public.auth_user VALUES (2, 'pbkdf2_sha256$600000$MdBJKgP4PoCzqG5ucWTDGY$M6kXv4LhmdXqbDhaOlSGzYlxyhDlRdmmRqSPmB75SG0=', NULL, false, 'test', '', '', '', true, true, '2023-04-17 20:28:47+05:30');


--
-- TOC entry 3450 (class 0 OID 16444)
-- Dependencies: 227
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3452 (class 0 OID 16450)
-- Dependencies: 229
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.auth_user_user_permissions VALUES (1, 2, 25);
INSERT INTO public.auth_user_user_permissions VALUES (2, 2, 31);


--
-- TOC entry 3454 (class 0 OID 16508)
-- Dependencies: 231
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_admin_log VALUES (1, '2023-04-17 20:28:48.317237+05:30', '2', 'test', 1, '[{"added": {}}]', 4, 1);
INSERT INTO public.django_admin_log VALUES (2, '2023-04-17 20:33:41.318173+05:30', '2', 'test', 2, '[{"changed": {"fields": ["Staff status", "User permissions"]}}]', 4, 1);
INSERT INTO public.django_admin_log VALUES (3, '2023-04-17 20:42:19.547316+05:30', '1', 'Product object (1)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (4, '2023-04-17 20:42:34.383105+05:30', '2', 'Product object (2)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (5, '2023-04-17 20:45:16.164684+05:30', '3', 'Product object (3)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (6, '2023-04-17 20:45:44.276617+05:30', '3', 'Product object (3)', 2, '[{"changed": {"fields": ["Name"]}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (7, '2023-04-17 20:49:32.748134+05:30', '4', 'Product object (4)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (8, '2023-04-18 08:21:27.972165+05:30', '5', 'Product object (5)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (9, '2023-04-18 08:22:34.320494+05:30', '6', 'Product object (6)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (10, '2023-04-18 08:22:46.53231+05:30', '7', 'Product object (7)', 1, '[{"added": {}}]', 7, 1);
INSERT INTO public.django_admin_log VALUES (11, '2023-04-18 08:45:53.279083+05:30', '8', 'Product object (8)', 1, '[{"added": {}}]', 7, 1);


--
-- TOC entry 3440 (class 0 OID 16408)
-- Dependencies: 217
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_content_type VALUES (1, 'admin', 'logentry');
INSERT INTO public.django_content_type VALUES (2, 'auth', 'permission');
INSERT INTO public.django_content_type VALUES (3, 'auth', 'group');
INSERT INTO public.django_content_type VALUES (4, 'auth', 'user');
INSERT INTO public.django_content_type VALUES (5, 'contenttypes', 'contenttype');
INSERT INTO public.django_content_type VALUES (6, 'sessions', 'session');
INSERT INTO public.django_content_type VALUES (7, 'myapp', 'product');
INSERT INTO public.django_content_type VALUES (8, 'myapp', 'offers');
INSERT INTO public.django_content_type VALUES (9, 'myapp', 'mymodel');


--
-- TOC entry 3438 (class 0 OID 16400)
-- Dependencies: 215
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_migrations VALUES (1, 'contenttypes', '0001_initial', '2023-04-17 19:59:59.444028+05:30');
INSERT INTO public.django_migrations VALUES (2, 'auth', '0001_initial', '2023-04-17 19:59:59.596911+05:30');
INSERT INTO public.django_migrations VALUES (3, 'admin', '0001_initial', '2023-04-17 19:59:59.626856+05:30');
INSERT INTO public.django_migrations VALUES (4, 'admin', '0002_logentry_remove_auto_add', '2023-04-17 19:59:59.638661+05:30');
INSERT INTO public.django_migrations VALUES (5, 'admin', '0003_logentry_add_action_flag_choices', '2023-04-17 19:59:59.643669+05:30');
INSERT INTO public.django_migrations VALUES (6, 'contenttypes', '0002_remove_content_type_name', '2023-04-17 19:59:59.655191+05:30');
INSERT INTO public.django_migrations VALUES (7, 'auth', '0002_alter_permission_name_max_length', '2023-04-17 19:59:59.662103+05:30');
INSERT INTO public.django_migrations VALUES (8, 'auth', '0003_alter_user_email_max_length', '2023-04-17 19:59:59.668697+05:30');
INSERT INTO public.django_migrations VALUES (9, 'auth', '0004_alter_user_username_opts', '2023-04-17 19:59:59.673698+05:30');
INSERT INTO public.django_migrations VALUES (10, 'auth', '0005_alter_user_last_login_null', '2023-04-17 19:59:59.68422+05:30');
INSERT INTO public.django_migrations VALUES (11, 'auth', '0006_require_contenttypes_0002', '2023-04-17 19:59:59.686811+05:30');
INSERT INTO public.django_migrations VALUES (12, 'auth', '0007_alter_validators_add_error_messages', '2023-04-17 19:59:59.693051+05:30');
INSERT INTO public.django_migrations VALUES (13, 'auth', '0008_alter_user_username_max_length', '2023-04-17 19:59:59.707158+05:30');
INSERT INTO public.django_migrations VALUES (14, 'auth', '0009_alter_user_last_name_max_length', '2023-04-17 19:59:59.713758+05:30');
INSERT INTO public.django_migrations VALUES (15, 'auth', '0010_alter_group_name_max_length', '2023-04-17 19:59:59.720315+05:30');
INSERT INTO public.django_migrations VALUES (16, 'auth', '0011_update_proxy_permissions', '2023-04-17 19:59:59.726865+05:30');
INSERT INTO public.django_migrations VALUES (17, 'auth', '0012_alter_user_first_name_max_length', '2023-04-17 19:59:59.734863+05:30');
INSERT INTO public.django_migrations VALUES (18, 'myapp', '0001_initial', '2023-04-17 19:59:59.743635+05:30');
INSERT INTO public.django_migrations VALUES (19, 'sessions', '0001_initial', '2023-04-17 19:59:59.769362+05:30');
INSERT INTO public.django_migrations VALUES (20, 'myapp', '0002_offers', '2023-04-17 20:14:50.143425+05:30');
INSERT INTO public.django_migrations VALUES (21, 'myapp', '0003_mymodel', '2023-04-18 09:15:40.495495+05:30');


--
-- TOC entry 3457 (class 0 OID 16542)
-- Dependencies: 234
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.django_session VALUES ('9m5accjl8dy0hrc6r86twpf82wy62ee4', '.eJxVjMsOwiAQRf-FtSE8hlJcuvcbyMxApWogKe3K-O_apAvd3nPOfYmI21ri1vMS5yTOQovT70bIj1x3kO5Yb01yq-syk9wVedAury3l5-Vw_w4K9vKtDWMIABwcKEeaPGP2mKfg2dLoFAEYNEYpqwcNmIdJO2vDmCyAc2TE-wPWvTcA:1poQHX:JB_MTdNy4mgpIhDXm1bu_mqcgBz_UsrtHgm9L8UPAzs', '2023-05-01 20:26:39.989453+05:30');


--
-- TOC entry 3461 (class 0 OID 16558)
-- Dependencies: 238
-- Data for Name: myapp_mymodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.myapp_mymodel VALUES (1, 'John', 1234, true);
INSERT INTO public.myapp_mymodel VALUES (2, 'Mary Alice', 4332, true);
INSERT INTO public.myapp_mymodel VALUES (3, 'Ahmed', 4555, false);
INSERT INTO public.myapp_mymodel VALUES (4, 'deepali', 5566, true);


--
-- TOC entry 3459 (class 0 OID 16552)
-- Dependencies: 236
-- Data for Name: myapp_offers; Type: TABLE DATA; Schema: public; Owner: postgres
--



--
-- TOC entry 3456 (class 0 OID 16537)
-- Dependencies: 233
-- Data for Name: myapp_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

INSERT INTO public.myapp_product VALUES (1, 'Apple', 20, 500);
INSERT INTO public.myapp_product VALUES (2, 'Orange', 25, 400);
INSERT INTO public.myapp_product VALUES (3, 'Kiwi1', 15, 200);
INSERT INTO public.myapp_product VALUES (4, 'Pineapple', 30, 300);
INSERT INTO public.myapp_product VALUES (5, 'Sapota', 30, 500);
INSERT INTO public.myapp_product VALUES (6, 'Fruit', 22, 33);
INSERT INTO public.myapp_product VALUES (7, 'Jam', 22, 344);
INSERT INTO public.myapp_product VALUES (8, 'test fruit', 22, 455);


--
-- TOC entry 3469 (class 0 OID 0)
-- Dependencies: 220
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 222
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 218
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 36, true);


--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 226
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 224
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 228
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 2, true);


--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 230
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 11, true);


--
-- TOC entry 3476 (class 0 OID 0)
-- Dependencies: 216
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 9, true);


--
-- TOC entry 3477 (class 0 OID 0)
-- Dependencies: 214
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 21, true);


--
-- TOC entry 3478 (class 0 OID 0)
-- Dependencies: 237
-- Name: myapp_mymodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.myapp_mymodel_id_seq', 4, true);


--
-- TOC entry 3479 (class 0 OID 0)
-- Dependencies: 235
-- Name: myapp_offers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.myapp_offers_id_seq', 1, false);


--
-- TOC entry 3480 (class 0 OID 0)
-- Dependencies: 232
-- Name: myapp_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.myapp_product_id_seq', 8, true);


-- Completed on 2023-04-18 10:08:53

--
-- PostgreSQL database dump complete
--

